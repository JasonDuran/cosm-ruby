#Following files were modified.
Gemfile
.ruby-version
.rvmrc
./01_dictionary/dictionary.rb
./02_cosm/feed.rb
./02_cosm/cosm_parser.rb
